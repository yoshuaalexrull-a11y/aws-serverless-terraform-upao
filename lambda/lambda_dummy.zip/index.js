exports.handler = async (event) => {
    return { statusCode: 200, body: 'Hola desde AWS' };
};